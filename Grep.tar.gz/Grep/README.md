Objective : To write the grep command

Grep : Globally search for regular expression and print out.

It looks for the specified expression and prints the line containing that 
expression.

Various options are specified to slightly modify the output.

Options : -r  -i  -v  -f  -w  -c  -m  -b -q  -H  -h -e
